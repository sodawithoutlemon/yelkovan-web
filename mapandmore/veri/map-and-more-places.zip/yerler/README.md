# Hazır yer kataloğu (`assets/yerler/`)

Map & More'un 150 hedef şehri için Gez, Ye ve İç sekmelerindeki gerçek yerler.
Her şehir bir dosya: `<cityId>.json` (`cityId` = `GeoCatalog.cities` kimliği).
Dosyalar `tool/yerler/` hattıyla üretilir; elle düzenlenmez.

## Kaynaklar ve lisans

- **OpenStreetMap** (yeme ve içme mekânları, bazı Gez yerlerinin OSM kimliği):
  © OpenStreetMap contributors. Veri **Open Database License (ODbL) 1.0** ile
  sunulur: <https://www.openstreetmap.org/copyright>. Bu klasördeki OSM
  türevi veri de ODbL 1.0 ile yayımlanır; uygulamada "© OpenStreetMap
  contributors" atfı verilir. OSM verisine OpenFreeMap vektör karoları
  (OpenMapTiles şeması, haftalık OSM gezegen dökümü) ya da Overpass API
  üzerinden erişildi; hangisinin kullanıldığı ve döküm tarihi her dosyanın
  `sources` alanında yazılıdır.
- **Wikidata** (görülecek yerler, çok dilli adlar, popülerlik, görsel adı):
  **CC0 1.0**, atıf gerekmez: <https://www.wikidata.org/wiki/Wikidata:Licensing>.
- **Wikimedia Commons** (fotoğraflar): yalnız adres yazılır, görsel
  indirilmez. Her fotoğrafın yazarı (`credit`), lisansı (`license`; yalnız
  CC0, kamu malı, CC BY, CC BY-SA) ve dosya sayfası (`page`) yerin `photo`
  alanındadır; uygulama fotoğrafı bu atıfla gösterir.

Seyahat rehberlerinden ve yorum sitelerinden metin alınmadı. Her yerin bir
Wikidata (`Q…`) ya da OSM (`node|way|relation/…`) kimliği vardır; koordinat
kaynaktan gelir.

## Biçim

`run11/brif/hazir-yerler.md` → "Çıktı biçimi". Her satır bir yer; alanlar
`id, kind, icon, name, local, lat, lon, minutes, indoor, part, tags, hours,
rank, area, wikidata, osm, photo`. `name` yalnız İngilizceden farklı olan
dilleri taşır (uygulama `en`'e düşer).

Denetim: `python3 tool/yerler/denetle.py` (rapor `tool/yerler/RAPOR.txt`).
